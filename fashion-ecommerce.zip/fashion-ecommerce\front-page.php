<?php
if (!defined('ABSPATH')) { exit; }
get_header();

$of_home_slug = sanitize_title(get_theme_mod('of_home_category', 'rl-zipper'));
$of_home_term = $of_home_slug ? get_term_by('slug', $of_home_slug, 'product_cat') : false;
$of_sort = isset($_GET['of_sort']) ? sanitize_key(wp_unslash($_GET['of_sort'])) : 'default';
$of_sort_options = array(
    'default' => __('Default', 'overview-fashion'),
    'price' => __('Price: Low to High', 'overview-fashion'),
    'price-desc' => __('Price: High to Low', 'overview-fashion'),
    'discount' => __('Biggest discount', 'overview-fashion'),
);
if (!isset($of_sort_options[$of_sort])) { $of_sort = 'default'; }
$of_catalog_args = array('limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC');
if ($of_home_term) { $of_catalog_args['category'] = array($of_home_term->slug); }
if ($of_sort === 'price') { $of_catalog_args['orderby'] = 'price'; $of_catalog_args['order'] = 'ASC'; }
if ($of_sort === 'price-desc') { $of_catalog_args['orderby'] = 'price'; $of_catalog_args['order'] = 'DESC'; }
if ($of_sort === 'discount') { $of_catalog_args['orderby'] = 'meta_value_num'; $of_catalog_args['meta_key'] = '_sale_price'; $of_catalog_args['order'] = 'ASC'; }
$of_hero_slides = array(
    array('image' => get_theme_mod('of_cover_banner')),
    array('image' => get_theme_mod('of_cover_banner_2')),
    array('image' => get_theme_mod('of_cover_banner_3')),
);
foreach ($of_hero_slides as $of_index => $of_slide) {
    if (!$of_hero_slides[$of_index]['image']) {
        $of_default_image = $of_index === 0 ? 'cover.jpeg' : 'banner-' . ($of_index + 1) . '.jpg';
        $of_hero_slides[$of_index]['image'] = get_template_directory_uri() . '/assets/' . $of_default_image;
    }
}
?>
<section class="of-home-hero" aria-roledescription="carousel" aria-label="<?php esc_attr_e('Featured collections', 'overview-fashion'); ?>">
  <div class="of-home-hero-track" data-of-slider>
    <?php foreach ($of_hero_slides as $of_index => $of_slide) : ?>
      <div class="of-home-hero-slide<?php echo $of_index === 0 ? ' is-active' : ''; ?>" style="--of-home-hero-image:url('<?php echo esc_url($of_slide['image']); ?>')" role="img" aria-label="<?php echo esc_attr(sprintf(__('Featured banner %d', 'overview-fashion'), $of_index + 1)); ?>" aria-hidden="<?php echo $of_index === 0 ? 'false' : 'true'; ?>"></div>
    <?php endforeach; ?>
  </div>
  <button class="of-home-hero-arrow of-home-hero-prev" type="button" data-of-prev aria-label="<?php esc_attr_e('Previous banner', 'overview-fashion'); ?>">‹</button>
  <button class="of-home-hero-arrow of-home-hero-next" type="button" data-of-next aria-label="<?php esc_attr_e('Next banner', 'overview-fashion'); ?>">›</button>
  <div class="of-home-hero-dots" data-of-dots role="group" aria-label="<?php esc_attr_e('Choose a banner', 'overview-fashion'); ?>"></div>
</section>
<div class="of-catalog-toolbar">
  <h1 class="of-catalog-title"><?php echo esc_html($of_home_term ? $of_home_term->name : __('All Products', 'overview-fashion')); ?></h1>
  <details class="of-sort-menu"><summary><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h9m4 0h3M4 17h3m4 0h9M13 4v6M9 14v6"></path><circle cx="15" cy="7" r="2"></circle><circle cx="9" cy="17" r="2"></circle></svg><?php esc_html_e('Sorting', 'overview-fashion'); ?></summary>
    <div class="of-sort-options">
      <?php foreach ($of_sort_options as $of_key => $of_label) : ?>
        <a class="<?php echo $of_sort === $of_key ? 'active' : ''; ?>" href="<?php echo esc_url(add_query_arg('of_sort', $of_key, remove_query_arg('of_sort'))); ?>"><?php echo esc_html($of_label); ?></a>
      <?php endforeach; ?>
    </div>
  </details>
</div>
<div id="of-home-products"><?php overview_fashion_products($of_catalog_args); ?></div>
<?php get_footer(); ?>
